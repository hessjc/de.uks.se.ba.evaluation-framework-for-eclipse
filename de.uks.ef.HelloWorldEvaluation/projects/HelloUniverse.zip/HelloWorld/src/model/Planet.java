package model;

public interface Planet
{
   public void sayHello();
}