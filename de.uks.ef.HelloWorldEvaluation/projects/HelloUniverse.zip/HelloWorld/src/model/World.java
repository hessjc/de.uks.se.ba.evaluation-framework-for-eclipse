package model;

public class World implements Planet
{
   @Override
   public void sayHello()
   {
      System.out.println("Hello, World!");
   }
}