package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import test.sub.UniverseTest;
import test.sub.WorldTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({
      WorldTest.class,
      UniverseTest.class
})
public class HelloWorldTest
{
   
}