package test.sub;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import model.Planet;
import model.World;

import org.junit.Test;

public class WorldTest
{
   @Test
   public void testWorld()
   {
      World world = new World();
      assertNotNull(world);

      assertThat(world, instanceOf(World.class));
      assertThat(world, instanceOf(Planet.class));
   }

   @Test
   public void TestWorldTest()
   {
      assertTrue(true);
   }
}