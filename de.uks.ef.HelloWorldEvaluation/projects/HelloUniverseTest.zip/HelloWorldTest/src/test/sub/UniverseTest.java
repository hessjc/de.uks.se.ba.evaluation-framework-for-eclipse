package test.sub;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class UniverseTest
{
   @Test
   public void TestUniverseTest()
   {
      assertTrue(true);
   }
}